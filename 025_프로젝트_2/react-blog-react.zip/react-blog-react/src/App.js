function App() {
	return <>React</>;
}

export default App;
